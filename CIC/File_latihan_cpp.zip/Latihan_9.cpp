#include <stdio.h>
#include <conio.h>
#include <iostream>

using namespace std;

main()
{
    putchar('S');
    putchar('T');
    putchar('M');
    putchar('I');
    putchar('K');
    putchar('_');
    putchar('C');
    putchar('I');
    putchar('C');
}
