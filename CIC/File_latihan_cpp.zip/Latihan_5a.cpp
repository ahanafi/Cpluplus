#include <stdio.h>
#include <conio.h>
#include <iostream>

main()
{
    char nama[20] = "Ahmad Hanafi";
    int nilai = 100;
    printf("Hai! %s, Kamu mendapatkan nilai %d", nama, nilai);
    getch();
}
