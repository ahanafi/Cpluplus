#include <stdio.h>
#include <conio.h>
#include <iostream>

main()
{
    float a1 = 87.6, a2 = 77.80;

    printf("Nilai tugas 1 = %2.2f \n", a1);
    printf("Nilai tugas 2 = %2.4f \n", a2);
}
