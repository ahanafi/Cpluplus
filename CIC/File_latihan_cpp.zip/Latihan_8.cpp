#include <stdio.h>
#include <conio.h>
#include <iostream>

using namespace std;

main()
{
    char x[20] = "STMIK CIC CIREBON";
    puts("Saya kuliah di ");
    puts(x);
}
