#include <stdio.h>
#include <conio.h>
#include <iostream>

using namespace std;

main()
{
    int jumbel1 = 50, jumbel2 = 23;

    cout<<"Jumlah Beli 1 ="<<jumbel1<<endl;
    cout<<"Jumlah Beli 2 ="<<jumbel2<<endl;
}
