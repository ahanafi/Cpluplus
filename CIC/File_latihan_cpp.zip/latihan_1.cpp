/*
    Tujuan  : Latihan program pertama
    Nama    : Ahmad Hanafi
    NIM     : 2017102020
    Mata Kuliah : Algoritma dan Pemrograman 1
*/

#include <iostream>

using namespace std;
main()
{
    cout<<"Hello World!";
}
